package com.fauzanz.tb2_uas_fauzan.features.subject_crud;

public interface SubjectCrudListener {
    void onSubjectListUpdate(boolean isUpdate);
}
