package com.fauzanz.tb2_uas_fauzan.features.student_crud;

public interface StudentCrudListener {
    void onStudentListUpdate(boolean isUpdated);
}
