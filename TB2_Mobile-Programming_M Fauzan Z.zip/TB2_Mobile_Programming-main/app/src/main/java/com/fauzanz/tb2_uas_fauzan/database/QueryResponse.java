package com.fauzanz.tb2_uas_fauzan.database;

public interface QueryResponse<T> {
    void onSuccess(T data);
    void onFailure(String message);
}